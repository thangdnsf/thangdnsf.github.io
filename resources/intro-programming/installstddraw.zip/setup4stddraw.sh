#!/bin/sh
dpkg -i python3-pip_8.1.1-2ubuntu0.4_all.deb
apt-get update
dpkg -i python3-tk_3.5.1-1_amd64.deb
apt-get update
pip3 install --upgrade pip
pip3 install pygame
