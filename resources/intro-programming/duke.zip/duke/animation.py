import stddraw
import picture
images = 17          # number of images
WIDTH = 500
HEIGHT = 500          # images are 130-by-500
stddraw.setCanvasSize(WIDTH, HEIGHT)
stddraw.setXscale(0, WIDTH)
stddraw.setYscale(0, HEIGHT)

#main animation loop
t = 0
while True:
    i = 1 + (t % images)
    filename = "T" + str(i) + ".gif" # name of the ith image
    pic = picture.Picture(filename)
    stddraw.picture(pic,WIDTH/2.0, HEIGHT/2.0)
    stddraw.show(100)
    stddraw.clear()
    t += 1